// Mock ESP32 — simulates the boat sending telemetry to the server every
// second, moving along a small fake path. Run this alongside the server
// to test the whole pipeline before the real hardware arrives.
//
// When the real ESP32 firmware is ready, it just needs to POST the same
// JSON shape to the same /api/telemetry endpoint — nothing else changes.

const SERVER_URL = process.env.SERVER_URL || 'http://localhost:3000';

// Starting point — replace with your fish farm's approximate coordinates.
let lat = 23.8103;
let lng = 90.4125;
let heading = 0;
let battery = 100;

function jitter(v, amount) {
  return v + (Math.random() - 0.5) * amount;
}

async function sendTelemetry() {
  // Fake a slow drift/patrol path
  heading = (heading + 5) % 360;
  lat += Math.cos((heading * Math.PI) / 180) * 0.00005;
  lng += Math.sin((heading * Math.PI) / 180) * 0.00005;
  battery = Math.max(0, battery - 0.05);

  const data = {
    lat: parseFloat(lat.toFixed(6)),
    lng: parseFloat(lng.toFixed(6)),
    heading: Math.round(heading),
    speed: parseFloat(jitter(1.2, 0.4).toFixed(2)), // m/s
    ph: parseFloat(jitter(7.2, 0.3).toFixed(2)),
    temperature: parseFloat(jitter(28, 1).toFixed(1)), // Celsius
    battery: parseFloat(battery.toFixed(1)),
    timestamp: Date.now(),
  };

  try {
    const res = await fetch(`${SERVER_URL}/api/telemetry`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    console.log('[mock-esp32] sent:', data);
  } catch (err) {
    console.error('[mock-esp32] failed to send telemetry:', err.message);
  }
}

console.log(`[mock-esp32] simulating boat -> ${SERVER_URL}/api/telemetry (every 1s)`);
setInterval(sendTelemetry, 1000);
sendTelemetry();
