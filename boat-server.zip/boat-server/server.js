// Boat Server — receives telemetry from the ESP32 (or mock), serves the
// web dashboard, broadcasts live updates over WebSocket, and stores
// mission waypoints the boat should follow.

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const MISSION_FILE = path.join(DATA_DIR, 'mission.json');
const BOUNDARY_FILE = path.join(DATA_DIR, 'boundary.json');
const LOG_FILE = path.join(DATA_DIR, 'telemetry-log.jsonl');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(MISSION_FILE)) {
  fs.writeFileSync(MISSION_FILE, JSON.stringify({ waypoints: [], status: 'idle' }, null, 2));
}
if (!fs.existsSync(BOUNDARY_FILE)) {
  fs.writeFileSync(BOUNDARY_FILE, JSON.stringify({ points: [] }, null, 2));
}

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: '/ws' });

// Keep the most recent telemetry in memory so a freshly opened dashboard
// tab immediately has something to show instead of a blank map.
let latestTelemetry = null;

function broadcast(type, payload) {
  const msg = JSON.stringify({ type, payload });
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  });
}

wss.on('connection', (ws) => {
  console.log('[ws] dashboard connected');
  if (latestTelemetry) {
    ws.send(JSON.stringify({ type: 'telemetry', payload: latestTelemetry }));
  }
  ws.send(JSON.stringify({ type: 'mission', payload: readMission() }));
  ws.send(JSON.stringify({ type: 'boundary', payload: readBoundary() }));

  ws.on('close', () => console.log('[ws] dashboard disconnected'));
});

function readMission() {
  return JSON.parse(fs.readFileSync(MISSION_FILE, 'utf8'));
}

function readBoundary() {
  return JSON.parse(fs.readFileSync(BOUNDARY_FILE, 'utf8'));
}

// ---- Boat -> Server: telemetry ingestion ----
// Expected JSON body:
// { lat, lng, heading, speed, ph, temperature, battery, timestamp }
app.post('/api/telemetry', (req, res) => {
  const data = req.body;
  if (typeof data.lat !== 'number' || typeof data.lng !== 'number') {
    return res.status(400).json({ error: 'lat/lng required (numbers)' });
  }
  data.timestamp = data.timestamp || Date.now();
  latestTelemetry = data;

  // Append-only log, one JSON object per line — cheap history without a DB.
  fs.appendFile(LOG_FILE, JSON.stringify(data) + '\n', () => {});

  broadcast('telemetry', data);
  res.json({ ok: true });
});

app.get('/api/telemetry/latest', (req, res) => {
  res.json(latestTelemetry || {});
});

// ---- Mission planning ----
// Dashboard sets waypoints; boat polls (or gets pushed via WS) to fetch them.
app.get('/api/mission', (req, res) => {
  res.json(readMission());
});

app.post('/api/mission', (req, res) => {
  const { waypoints } = req.body;
  if (!Array.isArray(waypoints)) {
    return res.status(400).json({ error: 'waypoints must be an array of {lat,lng}' });
  }
  const mission = { waypoints, status: 'assigned', updatedAt: Date.now() };
  fs.writeFileSync(MISSION_FILE, JSON.stringify(mission, null, 2));
  broadcast('mission', mission);
  res.json({ ok: true, mission });
});

// Boat reports mission status changes (e.g. "running", "completed")
app.post('/api/mission/status', (req, res) => {
  const mission = readMission();
  mission.status = req.body.status || mission.status;
  fs.writeFileSync(MISSION_FILE, JSON.stringify(mission, null, 2));
  broadcast('mission', mission);
  res.json({ ok: true });
});

// ---- Boundary (no-go polygon) ----
// Shared across all connected dashboards, same pattern as mission.
app.get('/api/boundary', (req, res) => {
  res.json(readBoundary());
});

app.post('/api/boundary', (req, res) => {
  const { points } = req.body;
  if (!Array.isArray(points)) {
    return res.status(400).json({ error: 'points must be an array of [lat,lng]' });
  }
  const boundary = { points, updatedAt: Date.now() };
  fs.writeFileSync(BOUNDARY_FILE, JSON.stringify(boundary, null, 2));
  broadcast('boundary', boundary);
  res.json({ ok: true, boundary });
});

// ---- Water quality mapping (pH / temperature interpolation) ----
// Turns scattered sensor readings logged while patrolling into a full
// grid covering the pond, using Inverse Distance Weighting: each grid
// cell's value is a weighted average of nearby readings, weighted more
// heavily toward closer samples. Cells outside the drawn boundary are
// left blank.

function pointInPolygonServer(point, vs) {
  let inside = false;
  for (let i = 0, j = vs.length - 1; i < vs.length; j = i++) {
    const xi = vs[i][0], yi = vs[i][1];
    const xj = vs[j][0], yj = vs[j][1];
    const intersect = ((yi > point[1]) !== (yj > point[1])) &&
      (point[0] < (xj - xi) * (point[1] - yi) / (yj - yi) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

function readTelemetryPoints(maxPoints = 5000) {
  if (!fs.existsSync(LOG_FILE)) return [];
  const lines = fs.readFileSync(LOG_FILE, 'utf8').trim().split('\n').filter(Boolean);
  const recent = lines.slice(-maxPoints);
  const points = [];
  for (const line of recent) {
    try {
      const d = JSON.parse(line);
      if (typeof d.lat === 'number' && typeof d.lng === 'number') points.push(d);
    } catch (e) { /* skip malformed lines */ }
  }
  return points;
}

app.get('/api/water-quality', (req, res) => {
  const param = req.query.param === 'temperature' ? 'temperature' : 'ph';
  const resolution = Math.min(60, Math.max(10, parseInt(req.query.res) || 36));

  const boundary = readBoundary();
  if (!boundary.points || boundary.points.length < 3) {
    return res.status(400).json({ error: 'Draw and finish a boundary first.' });
  }

  const samples = readTelemetryPoints()
    .filter((d) => typeof d[param] === 'number')
    .map((d) => ({ lat: d.lat, lng: d.lng, value: d[param] }));

  if (samples.length < 3) {
    return res.status(400).json({
      error: 'Not enough sensor readings yet inside the pond to build a map. Keep patrolling.',
      sampleCount: samples.length,
    });
  }

  const lats = boundary.points.map((p) => p[0]);
  const lngs = boundary.points.map((p) => p[1]);
  const south = Math.min(...lats), north = Math.max(...lats);
  const west = Math.min(...lngs), east = Math.max(...lngs);

  const rows = resolution;
  const cols = resolution;
  const values = [];
  let min = Infinity, max = -Infinity;

  for (let r = 0; r < rows; r++) {
    const rowVals = [];
    const lat = south + ((r + 0.5) / rows) * (north - south);
    for (let c = 0; c < cols; c++) {
      const lng = west + ((c + 0.5) / cols) * (east - west);
      if (!pointInPolygonServer([lat, lng], boundary.points)) {
        rowVals.push(null);
        continue;
      }
      // Inverse Distance Weighting, power = 2
      let weightSum = 0, valueSum = 0, exact = null;
      for (const s of samples) {
        const dLat = s.lat - lat, dLng = s.lng - lng;
        const distSq = dLat * dLat + dLng * dLng;
        if (distSq < 1e-14) { exact = s.value; break; }
        const w = 1 / distSq;
        weightSum += w;
        valueSum += w * s.value;
      }
      const val = exact !== null ? exact : valueSum / weightSum;
      rowVals.push(val);
      if (val < min) min = val;
      if (val > max) max = val;
    }
    values.push(rowVals);
  }

  res.json({
    param, rows, cols,
    bounds: { south, north, west, east },
    values, min, max,
    sampleCount: samples.length,
    updatedAt: Date.now(),
  });
});

server.listen(PORT, () => {
  console.log(`Boat server running: http://localhost:${PORT}`);
  console.log(`Dashboard:           http://localhost:${PORT}`);
  console.log(`Telemetry endpoint:  POST http://localhost:${PORT}/api/telemetry`);
});
